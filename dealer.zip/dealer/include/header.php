

<link rel="stylesheet" type="text/css" href="css/3.css">
<link type="text/css" rel="stylesheet" href="css/dd.css"/>

<header class="header">
	
	<h1></h1>
	<div style="background-image:url(./img/Exide2.png);height:114px ;width:600px ; float:right; padding-left:4px;" ></div>
    
    
   




</header>